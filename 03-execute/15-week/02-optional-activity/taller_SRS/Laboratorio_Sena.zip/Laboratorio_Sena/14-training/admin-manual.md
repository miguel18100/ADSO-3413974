# Manual de Administrador

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Gestión de productos (CU-004)

1. Ingrese al módulo de productos.
2. Seleccione crear, editar, eliminar o consultar.
3. Para crear/editar, indique nombre, categoría, precio, stock mínimo y unidad.
4. Los cambios se reflejan inmediatamente en el módulo de ventas.

Nota: si intenta eliminar un producto con ventas registradas, el sistema solicitará confirmación.

## Gestión de usuarios (CU-005)

1. Ingrese al módulo de usuarios.
2. Cree un nuevo usuario indicando nombre, contraseña y rol (ROL-ADM o ROL-CAJ).
3. Puede editar o desactivar usuarios existentes.

## Cierre de caja (CU-003)

1. Seleccione la opción de cierre de caja.
2. Indique el rango de fecha.
3. El sistema genera el reporte con los totales de venta.
4. Imprima o exporte el reporte en PDF.

## Reportes de ventas (CU-006)

1. Seleccione el módulo de reportes.
2. Elija el tipo de reporte: por fecha, por cajero o diario.
3. Indique el filtro deseado.
4. Imprima o exporte el reporte en PDF.
