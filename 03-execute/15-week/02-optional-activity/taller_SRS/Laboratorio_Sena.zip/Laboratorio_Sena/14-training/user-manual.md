# Manual de Usuario (Cajero)

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Inicio de sesión

1. Ingrese su usuario y contraseña asignados por el administrador.
2. El sistema validará sus credenciales (RF-005).

## Registrar una venta (CU-001)

1. Busque y seleccione los productos por nombre o código (RF-009).
2. Ingrese las cantidades.
3. El sistema calculará automáticamente el subtotal, IVA y total (RF-002).
4. Confirme la venta.
5. El sistema registrará la transacción, actualizará el inventario e imprimirá el recibo.

Si un producto no tiene stock suficiente, el sistema le alertará antes de confirmar la venta.

## Consultar inventario

Puede consultar el stock de los productos en modo solo lectura y recibir alertas cuando un producto llegue al stock mínimo configurado.

## Cierre de sesión

La sesión se cerrará automáticamente tras 30 minutos de inactividad (RNF-005).
