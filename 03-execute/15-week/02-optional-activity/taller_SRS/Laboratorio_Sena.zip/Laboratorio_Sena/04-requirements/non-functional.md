# Requisitos No Funcionales (RNF)

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

| ID | Categoría | Descripción |
|----|-----------|-------------|
| RNF-001 | Rendimiento | El sistema debe responder en menos de 2 segundos por operación. |
| RNF-002 | Seguridad | Acceso obligatorio mediante usuario y contraseña con restricción por roles. |
| RNF-003 | Usabilidad | Interfaz en español colombiano, sencilla y de fácil aprendizaje. |
| RNF-004 | Capacidad | Soporte para hasta 3 usuarios simultáneos en red local. |
| RNF-005 | Seguridad de sesión | La sesión expirará automáticamente tras 30 minutos de inactividad. |
| RNF-006 | Escalabilidad | El sistema debe permitir ampliaciones futuras sin rediseño total. |
| RNF-007 | Disponibilidad | El sistema debe estar disponible de lunes a domingo en el horario de operación del supermercado: 8:00 a.m. – 8:00 p.m. (12 horas diarias). |
