# Requisitos Funcionales (RF)

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

| ID | Descripción | Prioridad | Tipo |
|----|-------------|-----------|------|
| RF-001 | Registrar ventas seleccionando productos y cantidades. | Alta | Funcional |
| RF-002 | Calcular automáticamente subtotal, IVA y total de cada venta. | Alta | Funcional |
| RF-003 | Actualizar el inventario automáticamente al registrar una venta. | Alta | Funcional |
| RF-004 | Generar alertas cuando un producto alcance el stock mínimo. | Alta | Funcional |
| RF-005 | Autenticar usuarios mediante credenciales y gestionar roles. | Alta | Funcional |
| RF-006 | Permitir crear, editar, eliminar y consultar productos (CRUD). | Alta | Funcional |
| RF-007 | Generar reportes de ventas por fecha, por cajero y cierre de caja. | Alta | Funcional |
| RF-008 | Registrar y consultar historial completo de transacciones. | Media | Funcional |
| RF-009 | Permitir búsqueda rápida de productos por nombre o código. | Media | Funcional |
| RF-010 | Exportar reportes en formato PDF. | Media | Funcional |

## Requisitos de Negocio (RN)

| ID | Descripción |
|----|-------------|
| RN-001 | Reducir a cero los errores de cálculo en caja. |
| RN-002 | Eliminar pérdidas económicas por productos agotados sin control. |
| RN-003 | Mejorar los tiempos de atención al cliente durante las ventas. |
| RN-004 | Optimizar el control financiero mediante reportes automáticos. |
