# Casos de Uso

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## CU-001 — Registrar Venta

| Campo | Descripción |
|-------|-------------|
| Actor principal | Cajero |
| Precondición | Usuario autenticado en el sistema. |
| Flujo principal | 1. El cajero busca y selecciona productos. 2. Ingresa cantidades. 3. El sistema calcula el total. 4. El cajero confirma la venta. 5. El sistema registra la transacción, actualiza el inventario e imprime el recibo. |
| Resultado | Venta registrada, inventario actualizado, recibo impreso. |
| Flujo alternativo | Si un producto no tiene stock suficiente, el sistema alerta al cajero antes de confirmar. |
| Excepciones | E1: Producto no encontrado — el sistema muestra "Producto no encontrado". E2: Stock = 0 — el sistema muestra "Sin stock disponible" y no permite agregar el producto. E3: Fallo de impresora — el sistema registra la venta igualmente y permite reimprimir el recibo cuando la impresora esté disponible. |

## CU-002 — Consultar Inventario

| Campo | Descripción |
|-------|-------------|
| Actor principal | Administrador |
| Precondición | Acceso autorizado con rol de administrador. |
| Flujo principal | 1. El administrador ingresa al módulo de inventario. 2. El sistema muestra el listado de productos con su stock actual. 3. Los productos bajo el mínimo se destacan con una alerta. |
| Resultado | Visualización del inventario con alertas de stock mínimo. |
| Excepciones | E1: No hay productos con stock bajo — "Todo el inventario está en niveles normales". E2: Producto sin stock mínimo configurado — no genera alerta y marca el campo como "Sin configurar". |

## CU-003 — Generar Cierre de Caja

| Campo | Descripción |
|-------|-------------|
| Actor principal | Administrador |
| Precondición | Acceso autorizado con rol de administrador. |
| Flujo principal | 1. El administrador selecciona la opción de cierre de caja. 2. Indica el rango de fecha. 3. El sistema genera el reporte con totales de ventas. 4. El administrador imprime o exporta en PDF. |
| Resultado | Reporte de cierre de caja generado y disponible para exportación. |
| Excepciones | E1: No hay ventas registradas en el día — el sistema pregunta si desea continuar con el cierre. E2: Fallo de impresora — el sistema guarda el reporte en formato digital para descarga o impresión posterior. |

## CU-004 — Gestionar Productos (CRUD)

| Campo | Descripción |
|-------|-------------|
| Actor principal | Administrador |
| Precondición | Usuario autenticado con rol de administrador. |
| Flujo principal | 1. El administrador ingresa al módulo de productos. 2. Selecciona la acción: crear, editar, eliminar o consultar. 3. Para crear/editar: ingresa nombre, categoría, precio, stock mínimo y unidad. 4. El sistema guarda los cambios y actualiza el catálogo. |
| Resultado | Producto creado, editado, eliminado o consultado exitosamente. |
| Flujo alternativo | Si se intenta eliminar un producto con ventas registradas, el sistema solicita confirmación antes de proceder. |
| Postcondición | El catálogo de productos queda actualizado inmediatamente. Los cambios de precio y stock se reflejan en el módulo de ventas de forma instantánea. |

## CU-005 — Gestionar Usuarios

| Campo | Descripción |
|-------|-------------|
| Actor principal | Administrador |
| Precondición | Usuario autenticado con rol de administrador. |
| Flujo principal | 1. El administrador ingresa al módulo de usuarios. 2. Puede crear un nuevo usuario indicando nombre, contraseña y rol (ROL-ADM o ROL-CAJ). 3. Puede editar datos o desactivar un usuario existente. 4. El sistema guarda los cambios y aplica los permisos correspondientes. |
| Resultado | Usuario creado, modificado o desactivado correctamente en el sistema. |
| Flujo alternativo | Si el nombre de usuario ya existe, el sistema notifica el conflicto y solicita uno diferente. |
| Postcondición | El usuario queda registrado con los permisos del rol asignado. Si fue desactivado, no podrá iniciar sesión hasta ser reactivado por el administrador. |

## CU-006 — Generar Reporte de Ventas

| Campo | Descripción |
|-------|-------------|
| Actor principal | Administrador |
| Precondición | Usuario autenticado con rol de administrador y ventas registradas en el período. |
| Flujo principal | 1. El administrador selecciona el módulo de reportes. 2. Elige el tipo: por fecha, por cajero o reporte diario. 3. Indica el rango o filtro deseado. 4. El sistema genera el reporte con totales, productos y cajeros. 5. El administrador puede imprimir o exportar en PDF. |
| Resultado | Reporte de ventas generado con los filtros aplicados, disponible para exportación. |
| Excepciones | E1: No existen ventas en el período seleccionado — mensaje informativo. E2: Error al generar PDF — el sistema permite visualizar el reporte en pantalla e intentar la exportación nuevamente. |
