# Matriz de Trazabilidad

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Trazabilidad por módulo, rol y requisito

| Módulo / Funcionalidad | ROL-ADM | ROL-CAJ | ROL-SIS | Prioridad | RF relacionado |
|--------------------------|---------|---------|---------|-----------|------------------|
| Iniciar sesión en el sistema | ✔ | ✔ | — | Alta | RF-005 |
| Registrar venta | ✔ | ✔ | — | Alta | RF-001, RF-002 |
| Buscar producto por nombre o código | ✔ | ✔ | — | Alta | RF-009 |
| Imprimir recibo de venta | ✔ | ✔ | — | Alta | RF-001 |
| Consultar inventario y stock | ✔ | Solo lectura | ✔ | Alta | RF-003, RF-004 |
| Recibir alertas de stock mínimo | ✔ | ✔ | ✔ | Alta | RF-004 |
| Crear, editar y eliminar productos (CRUD) | ✔ | ✗ | — | Alta | RF-006 |
| Gestionar usuarios y roles | ✔ | ✗ | — | Alta | RF-005 |
| Generar reportes de ventas por fecha | ✔ | ✗ | ✔ | Alta | RF-007 |
| Generar reporte de cierre de caja | ✔ | ✗ | ✔ | Alta | RF-007 |
| Exportar reportes en PDF | ✔ | ✗ | ✔ | Media | RF-010 |
| Consultar historial de transacciones | ✔ | ✗ | ✔ | Media | RF-008 |
| Actualizar inventario automáticamente | — | — | ✔ | Alta | RF-003 |

Convención: ✔ Acceso total | Solo lectura | ✗ Sin acceso | — No aplica

## Trazabilidad hallazgos → requisitos

| Hallazgo | Requisito Derivado |
|----------|----------------------|
| "No sé cuándo se va a acabar un producto." | RF-003 — Alertas de stock mínimo. |
| "A veces me equivoco sumando." | RF-001 + RN-001 — Cálculo automático de totales. |
| Empleado tarda en encontrar precios de productos. | Catálogo digital de productos (RF-009). |
| Producto agotado sin ningún registro de alerta. | Alertas automáticas de stock mínimo (RF-004). |
| Cierre de caja manual consume tiempo excesivo. | Generación automática de cierre de caja (RF-007). |
