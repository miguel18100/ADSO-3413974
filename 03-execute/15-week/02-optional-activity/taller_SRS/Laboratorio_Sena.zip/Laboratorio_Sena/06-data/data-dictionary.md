# Diccionario de Datos

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Entidades principales

| Entidad | Atributos Principales | Relación |
|---------|------------------------|----------|
| Producto | ID, nombre, categoría, precio, stock actual, stock mínimo, unidad. | Se asocia a líneas de venta y movimientos de inventario. |
| Venta | ID, fecha, hora, total, IVA, cajero (usuario). | Contiene múltiples líneas de venta (productos vendidos). |
| Línea de Venta | ID, ID_venta, ID_producto, cantidad, precio unitario, subtotal. | Pertenece a una venta y referencia un producto. |
| Usuario | ID, nombre, contraseña (hash), rol, estado (activo/inactivo). | Registra quién realizó cada venta. |
| Categoría | ID, nombre, descripción. | Clasifica los productos del catálogo. |
| Movimiento Inventario | ID, ID_producto, tipo (entrada/salida), cantidad, fecha, motivo. | Registra cada cambio en el stock de un producto. |
