# Modelo de Datos

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Modelo entidad-relación (descripción textual)

- **Producto** (1) — (N) **Línea de Venta**: un producto puede aparecer en muchas líneas de venta.
- **Venta** (1) — (N) **Línea de Venta**: una venta contiene una o varias líneas de venta.
- **Usuario** (1) — (N) **Venta**: un usuario (cajero) registra muchas ventas.
- **Categoría** (1) — (N) **Producto**: una categoría agrupa muchos productos.
- **Producto** (1) — (N) **Movimiento Inventario**: cada cambio de stock de un producto se registra como un movimiento.

## Atributos por entidad

| Entidad | Atributos |
|---------|-----------|
| Producto | ID, nombre, categoría, precio, stock actual, stock mínimo, unidad |
| Venta | ID, fecha, hora, total, IVA, cajero (usuario) |
| Línea de Venta | ID, ID_venta, ID_producto, cantidad, precio unitario, subtotal |
| Usuario | ID, nombre, contraseña (hash), rol, estado (activo/inactivo) |
| Categoría | ID, nombre, descripción |
| Movimiento Inventario | ID, ID_producto, tipo (entrada/salida), cantidad, fecha, motivo |

Motor de base de datos: **MySQL 8.0** (ver `05-architecture/deployment.md`).
