# Product Backlog

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Backlog inicial (basado en Requisitos Funcionales)

| ID | Descripción | Prioridad | Módulo |
|----|-------------|-----------|--------|
| RF-001 | Registrar ventas seleccionando productos y cantidades. | Alta | Ventas |
| RF-002 | Calcular automáticamente subtotal, IVA y total de cada venta. | Alta | Ventas |
| RF-003 | Actualizar el inventario automáticamente al registrar una venta. | Alta | Inventario |
| RF-004 | Generar alertas cuando un producto alcance el stock mínimo. | Alta | Inventario |
| RF-005 | Autenticar usuarios mediante credenciales y gestionar roles. | Alta | Usuarios |
| RF-006 | Permitir crear, editar, eliminar y consultar productos (CRUD). | Alta | Productos |
| RF-007 | Generar reportes de ventas por fecha, por cajero y cierre de caja. | Alta | Reportes |
| RF-008 | Registrar y consultar historial completo de transacciones. | Media | Ventas |
| RF-009 | Permitir búsqueda rápida de productos por nombre o código. | Media | Productos |
| RF-010 | Exportar reportes en formato PDF. | Media | Reportes |
