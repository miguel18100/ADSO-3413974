# Visión del Producto

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Declaración de visión

Desarrollar un sistema de información de escritorio para el Supermercado "La Esquina" que automatice los procesos de ventas, control de inventario, gestión de usuarios y generación de reportes, eliminando errores manuales y mejorando la eficiencia operativa.

## Objetivos específicos

- Automatizar el registro de ventas y el cálculo de totales.
- Implementar control de inventario con alertas de stock mínimo.
- Gestionar usuarios con roles diferenciados (administrador y cajero).
- Generar reportes automáticos de ventas y cierre de caja.
- Mantener historial de transacciones y facilitar la toma de decisiones.

## Beneficios esperados

La implementación del sistema permitirá automatizar los procesos operativos y administrativos que actualmente se realizan de forma manual, eliminando los principales factores de error identificados durante la recolección de información. Los beneficios esperados incluyen: reducción de errores en caja, mayor velocidad en la atención al cliente, control efectivo del inventario, organización administrativa mejorada y generación automática de reportes financieros.

## Usuarios objetivo

| Nombre | Cargo en el Negocio | Rol en el Sistema | Acceso al Sistema |
|--------|----------------------|---------------------|---------------------|
| Don Carlos Rodríguez | Propietario y administrador | ROL-ADM | Acceso total al sistema. |
| Martha Rodríguez | Vendedora / Cajera | ROL-CAJ | Ventas y consulta de productos. |
| Julián Pérez | Vendedor / Cajero | ROL-CAJ | Ventas y consulta de productos. |
| Sistema | Actor automatizado | ROL-SIS | Ejecución interna sin intervención manual. |
