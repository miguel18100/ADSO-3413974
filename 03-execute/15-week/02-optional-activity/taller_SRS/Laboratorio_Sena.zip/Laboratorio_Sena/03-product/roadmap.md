# Roadmap

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Planificación del proyecto (versión 1.0)

| Fase | Duración estimada |
|------|---------------------|
| Recolección de requisitos | 2 semanas |
| Análisis del sistema | 2 semanas |
| Diseño del sistema | 3 semanas |
| Desarrollo | 6 semanas |
| Pruebas | 2 semanas |
| Implementación y capacitación | 2 semanas |
| **Total** | **17 semanas** |

## Costo estimado del proyecto

| Concepto | Valor estimado (COP) |
|----------|------------------------|
| Análisis del sistema | $1.000.000 |
| Diseño del software | $1.200.000 |
| Desarrollo del sistema | $3.000.000 |
| Configuración de base de datos | $700.000 |
| Pruebas del sistema | $500.000 |
| Capacitación | $400.000 |
| Implementación | $700.000 |
| Documentación | $300.000 |
| Mantenimiento inicial | $800.000 |
| **Total aproximado** | **$8.600.000** |

## Fuera de alcance / futuras versiones

- Facturación electrónica DIAN.
- Integración con datáfonos.
- Aplicación móvil.
- Gestión multi-sucursal.
- Tienda virtual y pagos en línea.
