# Glosario

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Nomenclatura y convenciones

| Término / Prefijo | Significado | Descripción |
|--------------------|--------------|-------------|
| SRS | Software Requirements Specification | Documento de Especificación de Requisitos de Software. |
| RF-### | Requisito Funcional | Describe una función o comportamiento específico del sistema. |
| RNF-### | Requisito No Funcional | Define atributos de calidad: rendimiento, seguridad, usabilidad, etc. |
| RN-### | Requisito de Negocio | Objetivo estratégico u operativo del negocio que el sistema debe apoyar. |
| CU-### | Caso de Uso | Describe una interacción entre un actor y el sistema para lograr un objetivo. |
| CRUD | Create, Read, Update, Delete | Operaciones básicas de gestión de datos. |
| IVA | Impuesto al Valor Agregado | Tributo aplicado sobre el precio de venta de productos gravados. |
| LAN | Local Area Network | Red de área local utilizada para la comunicación entre equipos del negocio. |
| MySQL | My Structured Query Language | Sistema gestor de base de datos relacional utilizado por el sistema. |
| ADSI | Análisis y Desarrollo de Software | Programa de formación del SENA al que pertenece el desarrollador. |
| SENA | Servicio Nacional de Aprendizaje | Institución de formación técnica y tecnológica de Colombia. |
| v1.0 | Versión 1.0 | Primera versión estable del sistema. |
| ROL-ADM | Rol Administrador | Perfil con acceso total al sistema. |
| ROL-CAJ | Rol Cajero | Perfil con acceso restringido a ventas y consulta de productos. |
| ROL-SIS | Rol Sistema | Actor automatizado que procesa información y genera reportes. |

## Glosario de negocio

| Término | Definición | Contexto |
|---------|------------|----------|
| Cajero | Persona encargada de atender al cliente y registrar las ventas en el punto de venta. | Negocio |
| Cierre de caja | Proceso al final del día en que se suman todas las ventas y se verifica que el dinero en caja coincida con el total registrado. | Negocio |
| Stock | Cantidad de unidades disponibles de un producto en el inventario. | Dominio |
| Stock mínimo | Cantidad mínima de unidades de un producto antes de generar una alerta de reabastecimiento. | Dominio |
| Inventario | Registro organizado de todos los productos disponibles, con sus cantidades y precios. | Dominio |
| Proveedor | Empresa o persona natural que suministra los productos que el supermercado comercializa. | Negocio |
| Punto de venta (POS) | Sistema o lugar donde se registra la transacción de compra. | Dominio |
| Recibo / Tiquete | Comprobante impreso con el detalle de los productos comprados y el total pagado. | Negocio |
| Descuadre de caja | Diferencia entre el dinero físico en caja y el total de ventas registrado. | Negocio |
| Reporte diario | Resumen automático del total de ventas, productos vendidos y cajero activo del día. | Dominio |
| Módulo | Componente funcional independiente del sistema (ej. módulo de ventas, inventario). | Sistema |
| Rol | Conjunto de permisos y accesos asignados a un tipo de usuario. | Sistema |
| Autenticación | Verificación de identidad mediante usuario y contraseña para acceder al sistema. | Sistema |
