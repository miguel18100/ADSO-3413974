# Overview

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Contexto institucional

Documento elaborado por Juan Miguel Muñoz, aprendiz del programa Análisis y Desarrollo de Software (ADSI) del SENA, ficha 3413974, como parte del proceso de análisis y desarrollo del proyecto formativo "Sistema de Información para el Supermercado La Esquina".

## Descripción del negocio

El Supermercado "La Esquina" es un negocio familiar ubicado en Neiva, Huila, dedicado a la comercialización de productos de consumo masivo: alimentos, bebidas, artículos de aseo y productos para el hogar. Cuenta con aproximadamente 90 productos registrados y realiza entre 22 y 89 ventas diarias, con un promedio de 50 transacciones. El sábado es el día de mayor afluencia.

El negocio es administrado por Don Carlos Rodríguez y atendido por Martha Rodríguez y Julián Pérez. Actualmente todos los procesos operativos se ejecutan de forma manual: registro de ventas en cuadernos, sumas con calculadora, listas de precios impresas y control de inventario en papel.

## Problema

Los procesos manuales actuales generan las siguientes problemáticas:

| N° | Problema | Impacto | Detección |
|----|----------|---------|-----------|
| 1 | Sumas manuales de ventas | Errores y descuadres de caja | Entrevista + Observación |
| 2 | Sin control de inventario en tiempo real | Productos agotados, pérdida de ventas | Entrevista |
| 3 | Lista de precios desactualizada | Errores en cobros y tiempo perdido | Revisión documental |
| 4 | Sin identificación del vendedor | Imposibilidad de auditoría | Revisión documental |
| 5 | Pedidos en papeles sueltos | Pérdida de información | Observación |

### Comparación de tiempos: método manual vs. sistema automatizado

| Proceso | Tiempo método manual | Tiempo con el sistema | Reducción |
|---------|----------------------|------------------------|-----------|
| Registro de una venta (5 productos) | 4 – 6 minutos | 1 – 2 minutos | ~70% |
| Búsqueda del precio de un producto | 2 – 4 minutos | < 10 segundos | ~95% |
| Verificación de stock de un producto | 5 – 10 minutos | < 5 segundos | ~98% |
| Cierre de caja diario | 30 – 50 minutos | 2 – 5 minutos | ~90% |
| Elaboración de pedido a proveedor | 20 – 40 minutos | 5 – 10 minutos | ~75% |
| Generación de reporte de ventas | No disponible (manual) | < 1 minuto | 100% |

## Objetivos

**Objetivo general:** Desarrollar un sistema de información de escritorio para el Supermercado "La Esquina" que automatice los procesos de ventas, control de inventario, gestión de usuarios y generación de reportes, eliminando errores manuales y mejorando la eficiencia operativa.

**Objetivos específicos:**
- Automatizar el registro de ventas y el cálculo de totales.
- Implementar control de inventario con alertas de stock mínimo.
- Gestionar usuarios con roles diferenciados (administrador y cajero).
- Generar reportes automáticos de ventas y cierre de caja.
- Mantener historial de transacciones y facilitar la toma de decisiones.

## Referencias

- IEEE Computer Society. (1998). IEEE Recommended Practice for Software Requirements Specifications (IEEE Std 830-1998).
- Pressman, R. S., & Maxim, B. R. (2021). Ingeniería del software: Un enfoque práctico (9.ª ed.). McGraw-Hill Education.
- Sommerville, I. (2016). Ingeniería del software (10.ª ed.). Pearson Educación.
- Servicio Nacional de Aprendizaje (SENA). (2024). Guía de aprendizaje: Análisis y Desarrollo de Software — ADSI.
- Muñoz, J. M. (2026, abril 11). Entrevista y observación directa al personal del Supermercado "La Esquina". Neiva, Huila, Colombia.
