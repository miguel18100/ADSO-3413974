# Alcance

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## En alcance (Versión 1.0)

| Módulo | Funcionalidades incluidas |
|--------|----------------------------|
| Ventas | Registro de ventas, cálculo automático de totales, impresión de recibos, asociación por cajero. |
| Inventario | Control de stock, alertas de mínimo, actualización automática y registro de movimientos. |
| Productos | Crear, editar, eliminar y clasificar productos por categoría. |
| Usuarios | Autenticación, gestión de roles y administración de usuarios. |
| Reportes | Reportes diarios, cierre de caja, reportes por fecha y por cajero. |

## Fuera de alcance (Versión 1.0)

- Facturación electrónica DIAN.
- Integración con datáfonos.
- Aplicación móvil.
- Gestión multi-sucursal.
- Tienda virtual y pagos en línea.

## Supuestos

- El supermercado cuenta con servicio eléctrico estable durante el horario de operación (8:00 a.m. – 8:00 p.m.).
- El negocio dispone de al menos un computador en buen estado para ejecutar el sistema.
- El personal tiene conocimiento básico en el manejo de Windows y uso del mouse y teclado.
- Se dispone de una red LAN funcional si se requiere uso multiusuario.
- Se cuenta con una impresora térmica compatible para la impresión de recibos.

## Restricciones

- El sistema funcionará únicamente en entornos Windows (versión 10 o superior).
- El sistema no requiere conexión a internet para operar; funciona en red local.
- No se incluirá facturación electrónica DIAN, pagos en línea ni gestión multi-sucursal en la versión 1.0.
- El sistema soporta máximo 3 usuarios activos al mismo tiempo.
- El sistema estará disponible únicamente en español colombiano.
