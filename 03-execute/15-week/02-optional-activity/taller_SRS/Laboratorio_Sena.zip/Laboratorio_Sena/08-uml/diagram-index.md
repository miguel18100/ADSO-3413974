# Índice de Diagramas

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

| Diagrama | Tipo | Caso de uso relacionado | Estado |
|----------|------|---------------------------|--------|
| Diagrama de casos de uso general | Caso de uso | CU-001 a CU-006 | 🔴 Pendiente de elaborar |
| Registrar Venta | Secuencia | CU-001 | 🔴 Pendiente de elaborar |
| Consultar Inventario | Secuencia | CU-002 | 🔴 Pendiente de elaborar |
| Generar Cierre de Caja | Secuencia | CU-003 | 🔴 Pendiente de elaborar |
| Gestionar Productos (CRUD) | Secuencia | CU-004 | 🔴 Pendiente de elaborar |
| Gestionar Usuarios | Secuencia | CU-005 | 🔴 Pendiente de elaborar |
| Generar Reporte de Ventas | Secuencia | CU-006 | 🔴 Pendiente de elaborar |
| Modelo entidad-relación | Clases / ER | Sección 5.3 SRS | 🔴 Pendiente de elaborar |

> Los archivos fuente y exportaciones de cada diagrama deben ubicarse en `08-uml/diagrams/source/` y `08-uml/diagrams/exports/` respectivamente, siguiendo `documentation-rules.md`.
