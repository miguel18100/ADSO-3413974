# Preguntas Abiertas

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

- ¿El sistema se desarrollará en Java o en C#? (El SRS deja ambas opciones abiertas en la sección de arquitectura, 5.1).
- ¿Se requiere soporte multi-impresora térmica o solo un modelo específico?
- ¿Quién administrará el servidor MySQL si el negocio amplía a más de un equipo?
- ¿Se contempla backup automático de la base de datos? (no definido explícitamente en el SRS).
