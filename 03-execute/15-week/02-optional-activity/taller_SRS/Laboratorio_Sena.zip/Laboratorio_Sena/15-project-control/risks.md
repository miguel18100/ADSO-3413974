# Riesgos

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Riesgos identificados (a partir de los hallazgos del SRS)

| N° | Riesgo / Problema actual | Impacto | Detección |
|----|----------------------------|---------|-----------|
| 1 | Sumas manuales de ventas | Errores y descuadres de caja | Entrevista + Observación |
| 2 | Sin control de inventario en tiempo real | Productos agotados, pérdida de ventas | Entrevista |
| 3 | Lista de precios desactualizada | Errores en cobros y tiempo perdido | Revisión documental |
| 4 | Sin identificación del vendedor | Imposibilidad de auditoría | Revisión documental |
| 5 | Pedidos en papeles sueltos | Pérdida de información | Observación |

## Riesgos del proyecto

- Disponibilidad limitada de equipo de cómputo en el negocio (mitigado por requisitos mínimos definidos en `05-architecture/deployment.md`).
- Dependencia de impresora térmica funcional para impresión de recibos (mitigado con flujo alternativo de reimpresión, CU-001).
- Resistencia al cambio del personal por uso manual histórico (mitigado con capacitación, ver `14-training/`).
