# Backlog Técnico

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

| ID | Descripción | Prioridad |
|----|-------------|-----------|
| RF-001 | Registrar ventas seleccionando productos y cantidades. | Alta |
| RF-002 | Calcular automáticamente subtotal, IVA y total de cada venta. | Alta |
| RF-003 | Actualizar el inventario automáticamente al registrar una venta. | Alta |
| RF-004 | Generar alertas cuando un producto alcance el stock mínimo. | Alta |
| RF-005 | Autenticar usuarios mediante credenciales y gestionar roles. | Alta |
| RF-006 | Permitir crear, editar, eliminar y consultar productos (CRUD). | Alta |
| RF-007 | Generar reportes de ventas por fecha, por cajero y cierre de caja. | Alta |
| RF-008 | Registrar y consultar historial completo de transacciones. | Media |
| RF-009 | Permitir búsqueda rápida de productos por nombre o código. | Media |
| RF-010 | Exportar reportes en formato PDF. | Media |
| RNF-001 a RNF-007 | Requisitos no funcionales — ver `04-requirements/non-functional.md`. | Alta/Media |
