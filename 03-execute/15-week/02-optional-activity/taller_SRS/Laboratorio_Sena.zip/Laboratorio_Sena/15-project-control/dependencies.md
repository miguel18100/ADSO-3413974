# Dependencias

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Dependencias técnicas

| Tipo | Elemento | Función |
|------|----------|---------|
| Software | Windows 10/11 | Sistema operativo anfitrión. |
| Software | MySQL 8.0+ | Gestión de base de datos. |
| Software | JDK 11+ / .NET 6+ | Entorno de ejecución de la aplicación. |
| Hardware | Computador (mín. Intel i3, 4GB RAM) | Equipo principal para ejecutar el sistema. |
| Hardware | Impresora térmica ESC/POS | Impresión de recibos de venta. |
| Red | LAN | Comunicación entre equipos si hay múltiples cajeros. |

## Dependencias organizacionales

- Disponibilidad de Don Carlos Rodríguez, Martha Rodríguez y Julián Pérez para pruebas de usuario y capacitación.
- Acceso del desarrollador (Juan Miguel Muñoz) al negocio para instalación e implementación.
