# Wireframes

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Pendiente

El SRS no incluye wireframes gráficos; queda pendiente diseñarlos en una fase posterior de diseño UI, a partir de los módulos definidos:

- Pantalla de inicio de sesión (RF-005).
- Pantalla de registro de venta / punto de venta (RF-001, RF-002, RF-009).
- Pantalla de inventario y alertas de stock mínimo (RF-003, RF-004).
- Pantalla de gestión de productos (CRUD) (RF-006).
- Pantalla de gestión de usuarios (RF-005).
- Pantalla de reportes y cierre de caja (RF-007, RF-008, RF-010).
