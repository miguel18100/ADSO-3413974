# Mapa de Navegación

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Módulos y navegación general (según rol)

```
Login
 └── Menú principal
      ├── Ventas (ROL-ADM, ROL-CAJ)
      │     └── Registrar venta / Buscar producto / Imprimir recibo
      ├── Inventario (ROL-ADM acceso total, ROL-CAJ solo lectura)
      │     └── Consultar stock / Alertas de stock mínimo
      ├── Productos (ROL-ADM)
      │     └── Crear / Editar / Eliminar / Consultar (CRUD)
      ├── Usuarios (ROL-ADM)
      │     └── Crear / Editar / Desactivar usuario
      └── Reportes (ROL-ADM)
            └── Reporte de ventas / Cierre de caja / Exportar PDF
```

Basado en la matriz de permisos de `04-requirements/traceability-matrix.md`.
