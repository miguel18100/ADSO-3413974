# Despliegue y Requisitos de Instalación

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Requisitos de instalación y ambiente mínimo

| Componente | Mínimo requerido | Recomendado |
|------------|-------------------|-------------|
| Sistema operativo | Windows 10 (64 bits) | Windows 10 / 11 (64 bits) |
| Procesador | Intel Core i3 o equivalente | Intel Core i5 o superior |
| Memoria RAM | 4 GB | 8 GB |
| Espacio en disco | 500 MB libres | 1 GB libres |
| Resolución de pantalla | 1024 × 768 px | 1280 × 720 px o superior |
| Java / .NET Runtime | JDK 11+ o .NET 6+ | JDK 17+ o .NET 8+ |
| MySQL Server | Versión 8.0 | Versión 8.0 o superior |
| Impresora | Térmica compatible con ESC/POS | Térmica 80 mm con driver Windows |
| Conexión de red | LAN (si hay múltiples equipos) | LAN 100 Mbps o superior |

## Modelo de despliegue

Despliegue local en red LAN: la aplicación de escritorio se instala en uno o varios equipos del supermercado, conectados a una instancia de MySQL Server (local o en un equipo servidor dentro de la misma red). No requiere conexión a internet (RNF / restricción "Uso offline").
