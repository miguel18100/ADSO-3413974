# Arquitectura del Sistema

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Arquitectura general

El sistema utilizará una arquitectura cliente-servidor con base de datos local MySQL, operando en red local (LAN). La aplicación de escritorio se desarrollará en Java o C# sobre el sistema operativo Windows.

## Componentes de software y hardware

| Tipo | Elemento | Función |
|------|----------|---------|
| Software | Windows | Sistema operativo anfitrión. |
| Software | MySQL | Gestión de base de datos. |
| Software | Java / C# | Lenguaje de desarrollo de la aplicación. |
| Hardware | Computador | Equipo principal para ejecutar el sistema. |
| Hardware | Impresora térmica | Impresión de recibos de venta. |
| Red | LAN local | Comunicación entre equipos del negocio. |

## Notas

Este es un sistema monolítico de escritorio (no microservicios); por esta razón las carpetas `07-api` y `09-microservices` de este repositorio se documentan como **No aplica** en la versión 1.0 — ver sus respectivos README.
