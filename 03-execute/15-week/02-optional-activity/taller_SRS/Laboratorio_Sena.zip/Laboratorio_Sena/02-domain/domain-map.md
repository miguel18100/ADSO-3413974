# Mapa de Dominio

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Entidades principales y relaciones

| Entidad | Atributos principales | Relación |
|---------|------------------------|----------|
| Producto | ID, nombre, categoría, precio, stock actual, stock mínimo, unidad. | Se asocia a líneas de venta y movimientos de inventario. |
| Venta | ID, fecha, hora, total, IVA, cajero (usuario). | Contiene múltiples líneas de venta (productos vendidos). |
| Línea de Venta | ID, ID_venta, ID_producto, cantidad, precio unitario, subtotal. | Pertenece a una venta y referencia un producto. |
| Usuario | ID, nombre, contraseña (hash), rol, estado (activo/inactivo). | Registra quién realizó cada venta. |
| Categoría | ID, nombre, descripción. | Clasifica los productos del catálogo. |
| Movimiento Inventario | ID, ID_producto, tipo (entrada/salida), cantidad, fecha, motivo. | Registra cada cambio en el stock de un producto. |

## Relaciones de alto nivel

- Un **Usuario** (cajero o administrador) registra una o varias **Ventas**.
- Una **Venta** contiene una o varias **Líneas de Venta**.
- Cada **Línea de Venta** referencia un **Producto**.
- Un **Producto** pertenece a una **Categoría**.
- Cada cambio de stock de un **Producto** genera un **Movimiento de Inventario** (entrada o salida).
