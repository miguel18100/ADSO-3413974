# Entidades y Reglas de Negocio

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Entidades del dominio

| Entidad | Atributos Principales | Relación |
|---------|------------------------|----------|
| Producto | ID, nombre, categoría, precio, stock actual, stock mínimo, unidad. | Se asocia a líneas de venta y movimientos de inventario. |
| Venta | ID, fecha, hora, total, IVA, cajero (usuario). | Contiene múltiples líneas de venta (productos vendidos). |
| Línea de Venta | ID, ID_venta, ID_producto, cantidad, precio unitario, subtotal. | Pertenece a una venta y referencia un producto. |
| Usuario | ID, nombre, contraseña (hash), rol, estado (activo/inactivo). | Registra quién realizó cada venta. |
| Categoría | ID, nombre, descripción. | Clasifica los productos del catálogo. |
| Movimiento Inventario | ID, ID_producto, tipo (entrada/salida), cantidad, fecha, motivo. | Registra cada cambio en el stock de un producto. |

## Reglas de negocio derivadas del SRS

- RN-001: Reducir a cero los errores de cálculo en caja (cálculo automático de subtotal, IVA y total — RF-002).
- RN-002: Eliminar pérdidas económicas por productos agotados sin control (alertas de stock mínimo — RF-004).
- RN-003: Mejorar los tiempos de atención al cliente durante las ventas.
- RN-004: Optimizar el control financiero mediante reportes automáticos (RF-007).
- Un producto no puede venderse si su stock disponible es 0 (ver excepción E2 de CU-001).
- Si se intenta eliminar un producto con ventas registradas, el sistema debe solicitar confirmación antes de proceder (CU-004).
- Si el nombre de usuario ya existe, el sistema debe notificar el conflicto y solicitar uno diferente (CU-005).
- La sesión de un usuario expira automáticamente tras 30 minutos de inactividad (RNF-005).
