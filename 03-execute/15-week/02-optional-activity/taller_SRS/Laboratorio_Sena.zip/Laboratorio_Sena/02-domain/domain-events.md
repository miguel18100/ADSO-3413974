# Eventos de Dominio

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Eventos identificados

| Evento | Disparado por | Efecto |
|--------|----------------|--------|
| VentaRegistrada | Cajero confirma una venta (CU-001) | Se actualiza el inventario, se calcula el total y se imprime el recibo. |
| StockActualizado | Registro de una venta o ingreso de mercancía | Se genera un Movimiento de Inventario (entrada/salida). |
| AlertaStockMinimoGenerada | El stock actual de un producto llega al stock mínimo configurado | El sistema notifica al cajero/administrador (RF-004). |
| ProductoCreado / ProductoEditado / ProductoEliminado | Administrador gestiona el catálogo (CU-004) | El catálogo de productos se actualiza inmediatamente y se refleja en ventas. |
| UsuarioCreado / UsuarioDesactivado | Administrador gestiona usuarios (CU-005) | Se aplican o revocan permisos según el rol asignado. |
| CierreCajaGenerado | Administrador solicita cierre de caja (CU-003) | Se genera el reporte de totales del día, disponible para impresión o exportación a PDF. |
| ReporteVentasGenerado | Administrador solicita reporte de ventas (CU-006) | Se genera el reporte filtrado por fecha o cajero, exportable a PDF. |
