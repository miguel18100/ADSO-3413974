# Lineamientos de API

> Estado: 🟢 | Última actualización: 2026-06-30
> Autor: Juan Miguel Muñoz | Equipo: Desarrollo SRS Supermercado La Esquina

## Nota

No aplica para la versión 1.0 del proyecto. El sistema "Supermercado La Esquina" es una **aplicación de escritorio monolítica** (cliente-servidor con MySQL local en red LAN), no una arquitectura de microservicios ni un servicio expuesto vía API REST. Ver `05-architecture/overview.md` para el detalle de la arquitectura definida en el SRS.
